// const mongoose = require('mongoose')

// const paymentSchema = new mongoose.Schema(
//     {
//         paymentId: {
//             type: mongoose.Types.ObjectId,
//             ref: "customerReg",
//         },
//         customerbill: {
//             type: String,
//             default: 0
//         },
//         balance: {
//             type: String,
//             default: 0
//         },
//         status: {
//             type: String,
//             default: "Active User"
//         },
//         amount_received: {
//             type: String,
//             default: 0
//         },
//     },
//     { timestamps: true }
// );
// module.exports = mongoose.model("Payment", paymentSchema)













